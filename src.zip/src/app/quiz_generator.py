def generate_quiz(detailed_notes):
    """
    Dummy quiz generator.
    Replace with your real quiz logic (OpenAI or custom).
    """
    return [
        "What is the main topic of the lecture?",
        "Describe one key point mentioned in the lecture.",
        "How can you apply the concepts discussed?"
    ]
