def transcribe_video(video_path):
    """
    Dummy transcription function.
    Replace this with your real integration (e.g., OpenAI Whisper).
    """
    return f"Dummy transcription for video at: {video_path}"
